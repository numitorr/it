Role Name
=========

This role installs and enables services for pcp, pmcd, and pmproxy.
Additionally it sets up PMDAs (plugins for pcp that pmcd runs as daemons) for
nginx, redis, and postgres as appropriate on AAP hosts.  Finally it sets up a
grafana with predefined datasources for the hosts using
the performance copilot plugin for grafana on the installer host (this is a
temporary standin for the gateway).

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

```
    - name: Setup monitoring for the AAP Cluster
      hosts: all
      gather_facts: no
      tasks:
        - include_role:
            name: automation_platform_installer.monitoring
```
